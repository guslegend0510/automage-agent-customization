# AutoMage-2 Landing Page (P0)

用于展示 AutoMage-2 MVP 的老板侧闭环演示页面（Executive Dashboard Demo）。

## 技术栈

- React + TypeScript + Vite
- Tailwind CSS
- Recharts
- Framer Motion
- Lucide React

## 快速启动

```bash
npm install
npm run dev
```

构建：

```bash
npm run build
```

## 环境变量

创建 `.env`（可选）：

```env
VITE_AUTOMAGE_API_BASE=http://localhost:8000
VITE_AUTOMAGE_AUTH_TOKEN=dev-token
VITE_AUTOMAGE_DEMO_MODE=true
```

- `VITE_AUTOMAGE_DEMO_MODE=true`：强制使用 mock fallback。
- `VITE_AUTOMAGE_DEMO_MODE=false`：优先请求 API，不可用时自动回退 mock。

## 模块说明

页面包含：

1. 顶部导航与联调状态徽标
2. Hero（定位、主链路、测试与风险）
3. Workflow 主链路
4. 三层 Agent 卡片
5. 老板侧 P0 Dashboard
6. Executive 决策卡
7. Manager 汇总面板
8. Staff 日报与任务回流
9. 任务看板
10. 风险与异常面板
11. API/DB/Schema 可信证明
12. Roadmap（P0/P1/P2）
