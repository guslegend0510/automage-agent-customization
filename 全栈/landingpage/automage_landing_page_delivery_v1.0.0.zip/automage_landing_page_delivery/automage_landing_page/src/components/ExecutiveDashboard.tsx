import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { toneDotClass } from '../lib/format'

interface Card {
  title: string
  value: string
  tone: 'green' | 'yellow' | 'red'
  description: string
}

interface Props {
  cards: Card[]
  taskStats: Array<{ name: string; value: number }>
}

export function ExecutiveDashboard({ cards, taskStats }: Props) {
  return (
    <section id="dashboard" className="space-y-4">
      <h2 className="section-title">老板侧 P0 Dashboard</h2>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {cards.map((item) => (
          <div key={item.title} className="glass-card rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-slate-300">{item.title}</p>
              <span className={`h-2.5 w-2.5 rounded-full ${toneDotClass(item.tone)}`} />
            </div>
            <p className="mt-3 text-xl font-semibold text-slate-100">{item.value}</p>
            <p className="mt-2 text-xs text-slate-400">{item.description}</p>
          </div>
        ))}
      </div>

      <div className="glass-card h-64 rounded-2xl p-4">
        <p className="mb-3 text-sm text-slate-300">今日任务状态分布</p>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={taskStats}>
            <XAxis dataKey="name" stroke="#94a3b8" />
            <YAxis stroke="#94a3b8" allowDecimals={false} />
            <Tooltip />
            <Bar dataKey="value" fill="#38bdf8" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </section>
  )
}
