import { motion } from 'framer-motion'

interface Props {
  title: string
  subtitle: string
  cards: Array<{ label: string; value: string }>
}

export function HeroSection({ title, subtitle, cards }: Props) {
  return (
    <section className="space-y-6 rounded-3xl border border-slate-700/40 bg-slate-950/60 p-8 shadow-2xl shadow-slate-900/50">
      <div className="space-y-4">
        <p className="inline-flex rounded-full border border-cyan-400/25 bg-cyan-500/10 px-3 py-1 text-xs text-cyan-200">
          Agent 时代的组织运行中枢
        </p>
        <h1 className="text-3xl font-bold tracking-tight text-slate-100 md:text-5xl">{title}</h1>
        <p className="max-w-4xl text-base text-slate-300 md:text-lg">{subtitle}</p>
        <div className="flex flex-wrap gap-2 text-sm">
          {['Schema Contract', 'Workflow First', 'Database as Source of Truth'].map((item) => (
            <span key={item} className="rounded-full border border-indigo-400/30 bg-indigo-500/10 px-3 py-1 text-indigo-200">
              {item}
            </span>
          ))}
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {cards.map((card, index) => (
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
            key={card.label}
            className="glass-card rounded-2xl p-4"
          >
            <p className="text-xs text-slate-400">{card.label}</p>
            <p className="mt-2 text-sm font-medium text-slate-100">{card.value}</p>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
