interface Props {
  mode: 'demo' | 'api'
}

export function SystemStatusBar({ mode }: Props) {
  const isApi = mode === 'api'
  return (
    <span
      className={`rounded-full border px-3 py-1 text-xs font-semibold ${
        isApi
          ? 'border-emerald-400/40 bg-emerald-500/15 text-emerald-300'
          : 'border-amber-400/40 bg-amber-500/15 text-amber-200'
      }`}
    >
      {isApi ? 'MVP Real API Passed' : 'Demo Mode'}
    </span>
  )
}
