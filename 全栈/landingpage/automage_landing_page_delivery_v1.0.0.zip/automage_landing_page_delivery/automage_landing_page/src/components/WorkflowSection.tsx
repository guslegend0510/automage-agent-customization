import type { WorkflowStep } from '../data/demoData'

interface Props {
  steps: WorkflowStep[]
}

export function WorkflowSection({ steps }: Props) {
  return (
    <section id="workflow" className="space-y-4">
      <h2 className="section-title">MVP 主链路 Workflow</h2>
      <div className="space-y-3">
        {steps.map((item, index) => (
          <div key={item.step} className="glass-card rounded-2xl p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-xs text-slate-400">Step {index + 1}</p>
                <p className="text-base font-semibold text-slate-100">{item.step}</p>
              </div>
              <span className="rounded-full border border-slate-500/40 px-2 py-1 text-xs text-slate-300">{item.status}</span>
            </div>
            <div className="mt-3 grid gap-2 text-sm text-slate-300 md:grid-cols-3">
              <p>角色：{item.role}</p>
              <p>数据表：{item.table}</p>
              <p>API：{item.api}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
