interface AgentCard {
  name: string
  duty: string[]
  output: string[]
  tables: string[]
}

interface Props {
  cards: AgentCard[]
}

export function AgentLayerCards({ cards }: Props) {
  return (
    <section id="agents" className="space-y-4">
      <h2 className="section-title">三层 Agent</h2>
      <div className="grid gap-4 lg:grid-cols-3">
        {cards.map((card) => (
          <article key={card.name} className="glass-card rounded-2xl p-5">
            <h3 className="text-lg font-semibold text-slate-100">{card.name}</h3>
            <div className="mt-3 space-y-2 text-sm text-slate-300">
              <p className="text-slate-400">职责</p>
              <ul className="list-disc space-y-1 pl-5">
                {card.duty.map((d) => (
                  <li key={d}>{d}</li>
                ))}
              </ul>
              <p className="pt-2 text-slate-400">输出</p>
              <ul className="list-disc space-y-1 pl-5">
                {card.output.map((o) => (
                  <li key={o}>{o}</li>
                ))}
              </ul>
              <p className="pt-2 text-slate-400">主要表</p>
              <div className="flex flex-wrap gap-2">
                {card.tables.map((t) => (
                  <span key={t} className="rounded bg-slate-800 px-2 py-1 text-xs text-cyan-200">
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}
