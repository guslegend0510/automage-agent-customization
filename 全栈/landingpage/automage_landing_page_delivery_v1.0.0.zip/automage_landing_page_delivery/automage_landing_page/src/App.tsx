import { useEffect, useMemo, useState } from 'react'
import { Footer } from './components/Footer'
import { HeroSection } from './components/HeroSection'
import { SystemStatusBar } from './components/SystemStatusBar'
import { WorkflowSection } from './components/WorkflowSection'
import {
  agentCards,
  auditTimelineDemo,
  dashboardCards,
  decisionCardDemo,
  heroStatusCards,
  incidentDemo,
  integrationStatus,
  landingMeta,
  managerSummaryDemo,
  staffReportDemo,
  taskBoardDemo,
  workflowSteps,
} from './data/demoData'
import { AgentLayerCards } from './components/AgentLayerCards'
import { ExecutiveDashboard } from './components/ExecutiveDashboard'
import { DecisionCard } from './components/DecisionCard'
import { ManagerSummaryPanel } from './components/ManagerSummaryPanel'
import { StaffReportPanel } from './components/StaffReportPanel'
import { TaskBoard } from './components/TaskBoard'
import { RiskIncidentPanel } from './components/RiskIncidentPanel'
import { AuditTimeline } from './components/AuditTimeline'
import { ApiDatabaseProof } from './components/ApiDatabaseProof'
import { apiProof, integrationProof, schemaProof, tableProof } from './data/apiMapping'
import { RoadmapSection } from './components/RoadmapSection'
import { fetchLandingData } from './lib/apiClient'

function App() {
  const [mode, setMode] = useState<'demo' | 'api'>('demo')
  const [apiBase, setApiBase] = useState('http://localhost:8000')
  const [healthOk, setHealthOk] = useState(integrationStatus.healthz)

  useEffect(() => {
    const bootstrap = async () => {
      const data = await fetchLandingData()
      setMode(data.mode)
      setApiBase(data.apiBase)
      setHealthOk(Boolean(data.healthz?.status))
    }
    void bootstrap()
  }, [])

  const taskStats = useMemo(() => {
    const counts = { pending: 0, in_progress: 0, blocked: 0, completed: 0 }
    taskBoardDemo.forEach((task) => {
      if (task.status === 'pending') counts.pending += 1
      if (task.status === 'in_progress') counts.in_progress += 1
      if (task.status === 'blocked') counts.blocked += 1
      if (task.status === 'completed') counts.completed += 1
    })
    return [
      { name: '待处理', value: counts.pending },
      { name: '进行中', value: counts.in_progress },
      { name: '阻塞', value: counts.blocked },
      { name: '已完成', value: counts.completed },
    ]
  }, [])

  return (
    <div className="mx-auto max-w-[1440px] px-4 pb-12 pt-4 md:px-8">
      <header className="sticky top-0 z-30 mb-5 rounded-2xl border border-slate-700/40 bg-slate-950/80 px-4 py-3 backdrop-blur">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-base font-semibold text-slate-100">AutoMage-2</p>
            <p className="text-xs text-slate-400">MVP Landing Page P0</p>
          </div>
          <nav className="flex flex-wrap items-center gap-3 text-xs text-slate-300">
            <a href="#workflow">闭环流程</a>
            <a href="#agents">三层 Agent</a>
            <a href="#decision">老板决策</a>
            <a href="#tasks">任务追踪</a>
            <a href="#integration">联调状态</a>
            <a href="#roadmap">Roadmap</a>
            <SystemStatusBar mode={mode} />
          </nav>
        </div>
      </header>

      <main className="space-y-8">
        <HeroSection title={landingMeta.title} subtitle={landingMeta.subtitle} cards={heroStatusCards} />
        <div className="rounded-xl border border-slate-700/40 bg-slate-900/40 p-3 text-xs text-slate-300">
          <p>
            AutoMage-2 不是普通日报系统，不是单纯项目管理工具，也不是空泛 AI 助手；它是 Staff / Manager / Executive
            分层 Agent 驱动的组织闭环系统。数据库是事实源，Schema 是契约，后端负责校验、权限、幂等、审计，老板保留关键确认权。
          </p>
          <p className="mt-2">
            当前联调：/healthz {healthOk ? '正常' : '异常'} ｜ pytest 30 passed ｜ 唯一风险：
            manager_cross_dept 当前未拒绝（非阻塞）。
          </p>
        </div>
        <WorkflowSection steps={workflowSteps} />
        <AgentLayerCards cards={agentCards} />
        <ExecutiveDashboard cards={dashboardCards} taskStats={taskStats} />
        <DecisionCard decision={decisionCardDemo} />
        <ManagerSummaryPanel summary={managerSummaryDemo} />
        <StaffReportPanel staff={staffReportDemo} />
        <TaskBoard tasks={taskBoardDemo} />
        <RiskIncidentPanel incidents={incidentDemo} />
        <AuditTimeline timeline={auditTimelineDemo} />
        <ApiDatabaseProof
          schemaProof={schemaProof}
          apiProof={apiProof}
          tableProof={tableProof}
          integrationProof={integrationProof}
        />
        <details className="glass-card rounded-2xl p-4 text-sm text-slate-300">
          <summary className="cursor-pointer text-slate-100">技术详情（统一联调身份）</summary>
          <div className="mt-3 grid gap-2 md:grid-cols-2">
            <p>org_id: {landingMeta.orgId}</p>
            <p>department_id: {landingMeta.departmentId}</p>
            <p>staff: {landingMeta.staffName}</p>
            <p>manager: {landingMeta.managerName}</p>
            <p>executive: {landingMeta.executiveName}</p>
            <p>staff node: {landingMeta.staffNode}</p>
            <p>manager node: {landingMeta.managerNode}</p>
            <p>executive node: {landingMeta.executiveNode}</p>
          </div>
        </details>
        <RoadmapSection />
      </main>

      <Footer apiBase={apiBase} />
    </div>
  )
}

export default App
