# LandingPage 验收清单

## 构建与运行

- [x] 本地 `npm install` 可完成
- [x] `npm run build` 通过
- [x] 页面无空白，首屏正常渲染
- [x] Mock 模式可用
- [x] API 不可用时自动 fallback，不崩溃

## 模块完整性

- [x] 顶部导航 + 状态徽标
- [x] Hero 区域
- [x] MVP 主链路 Workflow
- [x] 三层 Agent 卡片
- [x] 老板侧 Dashboard
- [x] Executive 决策卡（含交互）
- [x] Manager 汇总面板
- [x] Staff 日报与任务回流
- [x] 任务看板（含筛选）
- [x] 风险与异常面板
- [x] API/DB/Schema 可信证明区
- [x] Roadmap（P0/P1/P2）

## 数据可信与口径一致

- [x] P0 字段来源明确
- [x] 真实联调状态表述为“主链路通过 + 唯一风险”
- [x] 唯一风险 `manager_cross_dept` 被明确展示
- [x] 文案不含“全面生产可用”或“100% 自动决策”等过度承诺

## 安全与合规

- [x] 未暴露数据库密码
- [x] 未提交真实 token
- [x] 前端未直连 PostgreSQL

## 展示效果

- [x] 1440px 桌面展示正常
- [x] 13 寸笔记本布局可读
- [x] 移动端不崩溃（简化展示）
- [x] 深色科技感 + 控制台风格一致
